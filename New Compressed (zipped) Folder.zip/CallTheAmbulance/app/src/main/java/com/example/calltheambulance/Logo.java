package com.example.calltheambulance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ProgressBar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Logo extends Global {

    String type,phn,ph,p;
    DatabaseReference sReference;
    ProgressBar progressBar;
    FirebaseUser user;
    static ArrayList<Customer> scList;
    ArrayList<String> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logo);
        progressBar=findViewById ( R.id.logoProgress );
        user= FirebaseAuth.getInstance ().getCurrentUser ();
        progressBar.setVisibility ( View.VISIBLE );
        scList=new ArrayList<> (  ) ;
        list=new ArrayList<>();

        sReference= FirebaseDatabase.getInstance ().getReference ();
        sReference.child("Admin").child("Details").addValueEventListener ( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    list.clear();
                    for (DataSnapshot data:dataSnapshot.getChildren ()){
                        list.add(data.getValue().toString());

                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
        sReference.child ( "CustomerDetails" ).addValueEventListener ( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    scList.clear ();
                    for (DataSnapshot data:dataSnapshot.getChildren ()){
                        Customer customer=data.getValue (Customer.class);
                        scList.add ( customer );
                    }


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );

        Runnable r = new Runnable() {
            @Override
            public void run(){
                if(user!=null){
                    aPhNo=list.get(3);
                    aLoc=list.get(0);
                    aName=list.get(1);
                    price=list.get(4);
                    phn=user.getPhoneNumber ();
                    if(phn.equals(aPhNo)){
                        Intent i = new Intent ( Logo.this, AdminHome.class );
                        startActivity ( i );
                    }
                    else{

                        for(int i = 0; i<scList.size (); i++){
                            if(phn.equals ( scList.get ( i ).getPh () )){

                                gName= scList.get(i).getName();
                                gPhNo=scList.get(i).getPh();

                                Intent in = new Intent ( Logo.this, CustomerHome.class );
                                in.putExtra ( "Phone", gPhNo );
                                startActivity ( in );

                            }
                        }

                    }

                }
                else {
                    Intent i=new Intent ( Logo.this,MainActivity.class );
                    startActivity ( i );
                }

            }
        };
        Handler h = new Handler();
        h.postDelayed(r, 5000);

    }

    @Override
    public void onBackPressed() {
        // Add the Back key handler here.
        return;
    }
}