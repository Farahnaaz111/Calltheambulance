package com.example.calltheambulance;

import androidx.appcompat.app.AppCompatActivity;

public class Global extends AppCompatActivity {
    static String gName, gPhNo,aPhNo,aLoc,aName,price;
}
