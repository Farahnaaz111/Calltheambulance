package com.example.calltheambulance;

public class Customer {
    String Ph,Name,Pass;

    public Customer() {
    }

    public Customer(String ph, String name, String pass) {
        Ph = ph;
        Name = name;
        Pass = pass;
    }

    public String getPh() {
        return Ph;
    }

    public void setPh(String ph) {
        Ph = ph;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPass() {
        return Pass;
    }

    public void setPass(String pass) {
        Pass = pass;
    }
}

