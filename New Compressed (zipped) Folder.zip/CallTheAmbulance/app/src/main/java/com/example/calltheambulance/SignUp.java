package com.example.calltheambulance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hbb20.CountryCodePicker;

import java.util.ArrayList;

public class SignUp extends AppCompatActivity {

    EditText name, phone, pass;
    ArrayList<Customer> cList;
    DatabaseReference reference;
    CountryCodePicker ccp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        name= findViewById(R.id.sign_name);
        phone=findViewById(R.id.sign_phone);
        pass=findViewById(R.id.sign_pass);
        ccp=findViewById(R.id.ccp);
        ccp.registerCarrierNumberEditText(phone);
        cList=new ArrayList<> (  );
        reference= FirebaseDatabase.getInstance ().getReference ("CustomerDetails");
        reference.addValueEventListener ( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    cList.clear ();
                    for (DataSnapshot data:dataSnapshot.getChildren ()){
                        Customer customer=data.getValue (Customer.class);
                        cList.add ( customer );
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
    }
    public void onBackPressed() {
        // Add the Back key handler here.

        return;
    }

    public void signUp(View view) {
        String cName=name.getText ().toString ();
        String cPhone=ccp.getFullNumberWithPlus().replace(" ","");
        String cPass=pass.getText ().toString ();

        int count=0;
        if(cList.size()!=0){
            for(int i = 0; i<cList.size (); i++){
                if(cPhone.equals ( cList.get ( i ).getPh () )){
                    count++;
                }
            }
        }

        if(cName.isEmpty () || cPhone.isEmpty () || cPass.isEmpty ()) {
            Toast.makeText (SignUp.this,"Please fill all the details",Toast.LENGTH_SHORT).show ();
        }
        else if(count>0){
            Toast.makeText ( SignUp.this,"The Phone Number already exists",Toast.LENGTH_SHORT  ).show ();
        }
        else{

            Intent i =new Intent ( SignUp.this,PhoneVerification.class );
            i.putExtra ( "Phone",cPhone );
            i.putExtra ( "Name",cName );
            i.putExtra ( "Pass",cPass );
            startActivity ( i );
        }
    }


    public void signIn(View view) {
        startActivity ( new Intent(this,SignIn.class  ));
    }
}
