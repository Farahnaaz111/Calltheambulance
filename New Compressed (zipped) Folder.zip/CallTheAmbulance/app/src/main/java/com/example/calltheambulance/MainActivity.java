package com.example.calltheambulance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onBackPressed() {
        // Add the Back key handler here.

        return;
    }

    public void signUp(View view) {
        startActivity ( new Intent(this,SignUp.class  ));
    }

    public void signIn(View view) {
        startActivity ( new Intent (this,SignIn.class  ));
    }
}