package com.example.calltheambulance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.concurrent.TimeUnit;

public class PhoneVerification extends AppCompatActivity {

    private EditText codeEt;
    private FirebaseAuth firebaseAuth;
    private ProgressBar progressBar;
    DatabaseReference databaseReference;
    String phNo,pName,pPass;
    String otpId;
    int c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_verification);
        progressBar=findViewById ( R.id.progressbar );
        firebaseAuth=FirebaseAuth.getInstance ();
        c=0;
        databaseReference=  FirebaseDatabase.getInstance ().getReference ();
        codeEt = findViewById ( R.id.editTextCode );
        phNo=getIntent ().getStringExtra ( "Phone" );
        pName=getIntent ().getStringExtra ( "Name" );
        pPass=getIntent ().getStringExtra ( "Pass" );
        sendVerificationCode ( );
    }
    public void onBackPressed() {
        // Add the Back key handler here.

        return;
    }

    private  void sendVerificationCode(){
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phNo,
                60,
                TimeUnit.SECONDS,
                this,
                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                        otpId=s;
                        progressBar.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                        signInWithPhoneAuthCredential(phoneAuthCredential);
                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {
                        Toast.makeText(getApplicationContext(),"Signed in code error!",Toast.LENGTH_SHORT).show();
                        Log.w("Tag", "signInWithCredential:failure", e);

                    }
                }
        );
    }
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Toast.makeText(getApplicationContext(),"Signed in successfully!",Toast.LENGTH_SHORT).show();
                            Customer customer =new Customer (phNo,pName,pPass);
                            databaseReference.child ( "CustomerDetails" ).child ( phNo ).setValue (customer );
                            Runnable r = new Runnable() {
                                @Override
                                public void run() {
                                    progressBar.setVisibility ( View.INVISIBLE );
                                    Intent i =new Intent ( PhoneVerification.this,CustomerHome.class );
                                    startActivity ( i );

                                }
                            };


                            Handler h = new Handler();
                            h.postDelayed(r, 5000);

                            // Update UI
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w("Tag", "signInWithCredential:failure", task.getException());
                            Toast.makeText(getApplicationContext(),"Signed in code error!",Toast.LENGTH_SHORT).show();

                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                            }
                        }
                    }
                });
    }

    public void verified(View view) {
        String enCode=codeEt.getText ().toString ();
        if(enCode.isEmpty ()){
            Toast.makeText ( PhoneVerification.this,"Enter the code",Toast.LENGTH_SHORT  ).show ();
            return;

        }
        progressBar.setVisibility ( View.VISIBLE );
        PhoneAuthCredential credential=PhoneAuthProvider.getCredential(otpId,enCode);
        signInWithPhoneAuthCredential ( credential );

    }

    public void signIn(View view) {
        if(c==0){
            Toast.makeText ( PhoneVerification.this,"Please check the code",Toast.LENGTH_SHORT  ).show ();
        }
        else {
            Intent i =new Intent ( PhoneVerification.this,SignIn.class );
            startActivity ( i );

        }
    }
}
