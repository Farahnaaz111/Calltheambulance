package com.example.calltheambulance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hbb20.CountryCodePicker;

import java.util.ArrayList;

public class SignIn extends Global {

    EditText sPh,sPass;
    private ProgressBar sProgress;
    DatabaseReference cReference;
    static ArrayList<Customer> scList;
    CountryCodePicker ccp;
    ArrayList<String> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        sPh=findViewById ( R.id.sign_phone );
        sPass=findViewById ( R.id.sign_pass );
        ccp=findViewById(R.id.ccp);
        ccp.registerCarrierNumberEditText(sPh);
        sProgress=findViewById ( R.id.sProgress );
        scList=new ArrayList<> (  );
        list=new ArrayList<>();
        final String phoneNumber=sPh.getText ().toString ();
        cReference= FirebaseDatabase.getInstance ().getReference ();
        cReference.child("Admin").child("Details").addValueEventListener ( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    list.clear();
                    for (DataSnapshot data:dataSnapshot.getChildren ()){
                        list.add(data.getValue().toString());

                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
        cReference.child ( "CustomerDetails" ).addValueEventListener ( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    scList.clear ();
                    for (DataSnapshot data:dataSnapshot.getChildren ()){
                        Customer customer=data.getValue (Customer.class);
                        scList.add ( customer );
                    }


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
        cReference= FirebaseDatabase.getInstance ().getReference ();


    }
    @Override
    public void onBackPressed() {
        // Add the Back key handler here.

        return;
    }


    public void signUp(View view) {
        Intent intent =new Intent ( SignIn.this,SignUp.class );
        startActivity ( intent );
    }

    public void forgot(View view) {

        sProgress.setVisibility ( View.INVISIBLE );
        Toast.makeText(this,"Forgot Password",Toast.LENGTH_SHORT).show();


    }

    public void logIn(View view) {
        String Phone = ccp.getFullNumberWithPlus().replace(" ","");
        final String Pass=sPass.getText ().toString ();
        aPhNo=list.get(3);
        Toast.makeText ( SignIn.this,""+aPhNo,Toast.LENGTH_SHORT ).show ();
        aLoc=list.get(0);
        aName=list.get(1);
        price=list.get(4);
        if(Phone.isEmpty () || Pass.isEmpty ()){
            Toast.makeText ( SignIn.this,"Please fill the details.",Toast.LENGTH_SHORT ).show ();
            sProgress.setVisibility ( View.INVISIBLE );
        }
        else {
            sProgress.setVisibility ( View.VISIBLE );

            if(Phone.equals(aPhNo)){
                if(Pass.equals(list.get(2))){
                    Intent intent =new Intent ( SignIn.this,AdminHome.class );
                    startActivity ( intent );
                }
                else {
                    Toast.makeText ( getApplicationContext (),"The Password entered is incorrect",Toast.LENGTH_SHORT ).show ();

                }
            }
            else{

                final String finalPhone = Phone;
                Runnable r = new Runnable () {
                    @Override
                    public void run() {

                        int count=0;
                        if(scList.size()!=0){
                            for(int i = 0; i<scList.size (); i++){
                                if(finalPhone.equals ( scList.get ( i ).getPh () )){
                                    count++;
                                    if(Pass.equals ( scList.get ( i ).getPass ()  )){
                                        sProgress.setVisibility ( View.INVISIBLE );
                                        gName= scList.get(i).getName();
                                        gPhNo=scList.get(i).getPh();

                                        Intent intent =new Intent ( SignIn.this,CustomerHome.class );
                                        intent.putExtra ( "Phone", finalPhone );
                                        startActivity ( intent );
                                    }
                                    else{
                                        sProgress.setVisibility ( View.INVISIBLE );
                                        Toast.makeText ( getApplicationContext (),"The Password entered is incorrect",Toast.LENGTH_SHORT ).show ();
                                    }
                                }
                            }
                        }



                        if(count ==0){
                            Toast.makeText ( getApplicationContext (),"The User not Signed Up",Toast.LENGTH_SHORT ).show ();
                            sProgress.setVisibility ( View.INVISIBLE );
                        }
                    }


                };
                Handler h = new Handler ();
                h.postDelayed ( r, 10000 );

            }

        }
    }
}